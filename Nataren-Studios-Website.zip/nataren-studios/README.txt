NATAREN STUDIOS WEBSITE

Open index.html to view your complete website. Everything is in this file: design, styling, and interactions. No install or build needed.

PUBLISH
Upload index.html to your GitHub repository root. Import the repository in Vercel as an Other/static project. Leave build command empty and serve the root directory. Alternatively use any static web host.

CONTACT
The inquiry form opens the visitor's email app with a prepared message to natarenstudiosweb@hotmail.com. The visitor must press Send. There is no backend or database.

EDIT
Edit index.html in a text editor to change content. Search for your email to change it. Package scope is proposed website copy; review it before publishing. The featured project artwork is an illustrative presentation, not a screenshot. Future portfolio entries are labeled planned concepts.

No external fonts, images, tracking, dependencies, or API keys are required.

PROJECT POLICY
Founder: Esthefany Nataren. New requests or changes outside the original agreed scope cost extra. Agree on the additional price before doing the extra work.
